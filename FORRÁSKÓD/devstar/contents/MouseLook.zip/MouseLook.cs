﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseLook : MonoBehaviour
{
    public Transform playerBody;

    public float mouseSensitivity = 200f;
    public float headUp = 90f;
    public float headDown = 90f;

    private float rotateX;
    private float mouseX;
    private float mouseY;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        rotateUpDown();
        rotateAround();
    }

    private void rotateAround()
    {
        transform.localRotation = Quaternion.Euler(rotateX, 0f, 0f);
        playerBody.Rotate(Vector3.up * mouseX);
    }

    private void rotateUpDown()
    {
        rotateX -= mouseY;
        rotateX = Mathf.Clamp(rotateX, -headUp, headDown);
    }
}
