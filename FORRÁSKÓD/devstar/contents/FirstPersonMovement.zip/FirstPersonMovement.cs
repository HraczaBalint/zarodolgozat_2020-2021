﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstPersonMovement : MonoBehaviour
{
    [Header("Walking")]

    public CharacterController controller;
    public float walkingSpeed = 6f;
    private Vector3 move;

    [Space]
    [Header("Running")]

    public bool runAvbl = true;
    public float runSpeed = 8f;

    [Space]
    [Header("Ducking")]

    public bool duckAvbl = true;
    public float duckSpeed = 4f;
    public float defHeight = 3.58f;
    public float duckHeight = 2f;
    private bool isDucking = false;

    [Space]
    [Header("Jumping")]

    public bool jumpAvbl = true;
    public float jumpHeight = 3f;
    Vector3 fallSpeed = Vector3.zero;
    public LayerMask jumpableSurface;

    [Space]
    [Header("Falling")]

    public float gravity = -20f;
    public Transform groundCheck;
    public float gcSphereRadius = 0.4f;
    private bool isGrounded = false;

    [Space]
    [Header("Sliding")]

    public bool slideAvbl = true;
    private Vector3 angleOfArrival = Vector3.zero;
    private bool groundIsFlat = false;
    public float slideSpeed = 6f;


    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        angleOfArrival = hit.normal;

        if (hit.collider.tag != "Ground")
        {
            slideAvbl = false;
        }
        else
        {
            slideAvbl = true;
        }
    }


    void Update()
    {
        walking();
        running();
        ducking();
        falling();
    }

    private void falling()
    {
        isGrounded = Physics.CheckSphere(groundCheck.position, gcSphereRadius, jumpableSurface);

        if (isGrounded && fallSpeed.y < 0)
        {
            fallSpeed.y = -5f;
        }

        if (Input.GetKey(KeyCode.Space) && isGrounded && (!Input.GetKey(KeyCode.LeftControl)) && jumpAvbl)
        {
            fallSpeed.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }
        fallSpeed.y += gravity * Time.deltaTime;
        controller.Move(fallSpeed * Time.deltaTime);
    }

    private void ducking()
    {
        if (Input.GetKey(KeyCode.LeftControl) && isGrounded && duckAvbl)
        {
            isDucking = true;
            controller.height = duckHeight;
        }

        if (Input.GetKeyUp(KeyCode.LeftControl) && isDucking && duckAvbl)
        {
            isDucking = false;
            controller.height = defHeight;
        }
    }

    private void running()
    {
        if (Input.GetKey(KeyCode.LeftShift) && !Input.GetKey(KeyCode.LeftControl) && runAvbl == true)
        {
            controller.Move(move * runSpeed * Time.deltaTime);
        }
    }

    private void walking()
    {
        groundIsFlat = Vector3.Angle(Vector3.up, angleOfArrival) <= controller.slopeLimit;

        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        move = transform.right * x + transform.forward * z;

        if (!groundIsFlat && slideAvbl)
        {
            move.x = ((1f - angleOfArrival.y) * angleOfArrival.x) * slideSpeed;
            move.z = ((1f - angleOfArrival.y) * angleOfArrival.z) * slideSpeed;
        }

        controller.Move(move * walkingSpeed * Time.deltaTime);
    }

    
}
