﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DayNightChange : MonoBehaviour
{
    
    public new Camera camera;

    [Space]
    [Header("Sky color")]

    public Color middaySkyColor;
    public Color midnightSkyColor;

    [Space]
    [Header("Sky color")]

    public float lowFogDensity = 0.0045f;
    public float highFogDensity = 0.06f;

    [Space]
    [Header("Cycle")]

    public float timeInSeconds = 0;
    public float day = 0;
    public float fullCycleInMinutes = 1f;
    private float turn = 30f;
    private float t = 0;

    void FixedUpdate()
    {
        t = Time.time * 1 / (fullCycleInMinutes * turn);

        changeFog();
        changeDaylight();
        debug();
    }

    private void debug()
    {
        timeInSeconds = Time.time;

        if (camera.backgroundColor == midnightSkyColor)
        {
            Debug.Log("Midnight - " + timeInSeconds + " sec");
        }
        if (camera.backgroundColor == middaySkyColor)
        {
            Debug.Log("Midday - " + timeInSeconds + " sec");

            day++;
            Debug.Log("Day " + day);
        }
    }

    private void changeDaylight()
    {
        transform.Rotate(0, 6 * (1 / fullCycleInMinutes) * Time.deltaTime, 0);
        camera.backgroundColor = Color.Lerp(middaySkyColor, midnightSkyColor, Mathf.PingPong(t, 1));
    }

    private void changeFog()
    {
        RenderSettings.fogDensity = Mathf.Lerp(lowFogDensity, highFogDensity, Mathf.PingPong(t, 1));
    }
}
